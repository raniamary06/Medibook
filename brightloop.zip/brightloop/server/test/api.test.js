import { test, describe, before } from 'node:test';
import assert from 'node:assert/strict';
import { setup, TODAY } from './helpers.js';
const { runBilling } = await import('../src/services/billing.js');
const { addDays } = await import('../src/lib/util.js');

let ctx, admin, staff, customer;
before(async () => {
  ctx = await setup();
  admin = ctx.as('admin'); staff = ctx.as('staff'); customer = ctx.as('customer');
});

/** Helper: a clean product/plan/customer so seeded discounts don't interfere. */
async function fixture({ price = 1000, plan = {}, qty = 1 } = {}) {
  const tag = Math.random().toString(36).slice(2, 8);
  const p = await admin.post('/api/products', { name: `Test ${tag}`, type: 'service', sales_price: price, cost_price: 0 });
  const pl = await admin.post('/api/plans', { name: `Plan ${tag}`, billing_period: 'monthly', ...plan });
  const c = await staff.post('/api/customers', { name: `Cust ${tag}`, email: `c-${tag}@example.com` });
  assert.equal(p.status, 201); assert.equal(pl.status, 201); assert.equal(c.status, 201);
  return { product: p.body, plan: pl.body, customer: c.body, line: { product_id: p.body.id, quantity: qty } };
}
async function activeSub(f, start) {
  const s = await staff.post('/api/subscriptions', { customer_id: f.customer.id, plan_id: f.plan.id, start_date: start, lines: [f.line] });
  assert.equal(s.status, 201, JSON.stringify(s.body));
  for (const a of ['send_quote', 'confirm', 'activate']) assert.equal((await staff.post(`/api/subscriptions/${s.body.id}/${a}`)).status, 200);
  return s.body.id;
}
const invoicesOf = (id) => ctx.q.all(`SELECT * FROM invoices WHERE subscription_id = ? AND status <> 'cancelled' ORDER BY cycle_index`, id);

describe('Authentication & password policy', () => {
  test('rejects weak passwords with field messages', async () => {
    for (const pw of ['Short!1a', 'alllowercase!', 'ALLUPPERCASE!', 'NoSpecial123']) {
      const r = await ctx.anon.post('/api/auth/signup').send({ name: 'Weak', email: `w${pw.length}${pw[0]}@x.io`, password: pw });
      assert.equal(r.status, 400, pw);
      assert.ok(r.body.fields.password, pw);
    }
  });
  test('accepts a valid password (>8 chars, upper, lower, special)', async () => {
    const r = await ctx.anon.post('/api/auth/signup').send({ name: 'New Co', email: 'new@co.io', password: 'Valid#pass' });
    assert.equal(r.status, 201);
    assert.equal(r.body.user.role, 'customer');
  });
  test('email must be unique (case-insensitive)', async () => {
    const r = await ctx.anon.post('/api/auth/signup').send({ name: 'Dup', email: 'ADMIN@brightloop.io', password: 'Valid#pass' });
    assert.equal(r.status, 409);
  });
  test('wrong password is rejected with a generic message', async () => {
    const r = await ctx.anon.post('/api/auth/login').send({ email: 'admin@brightloop.io', password: 'Wrong@12345' });
    assert.equal(r.status, 401);
    assert.equal(r.body.error, 'Invalid email or password');
  });
  test('requests without a token are rejected', async () => {
    assert.equal((await ctx.anon.get('/api/subscriptions')).status, 401);
  });

  test('full password-reset flow via emailed link; token is single-use', async () => {
    const f = await ctx.anon.post('/api/auth/forgot-password').send({ email: 'staff@brightloop.io' });
    assert.equal(f.status, 200);
    const unknown = await ctx.anon.post('/api/auth/forgot-password').send({ email: 'nobody@x.io' });
    assert.deepEqual(unknown.body, f.body, 'no account enumeration');
    const mail = ctx.q.get(`SELECT * FROM email_outbox WHERE to_address = 'staff@brightloop.io' ORDER BY id DESC`);
    const token = mail.html.match(/token=([a-f0-9]{64})/)[1];
    assert.equal((await ctx.anon.post('/api/auth/reset-password').send({ token, password: 'weak' })).status, 400);
    assert.equal((await ctx.anon.post('/api/auth/reset-password').send({ token, password: 'Brand@New99' })).status, 200);
    assert.equal((await ctx.anon.post('/api/auth/reset-password').send({ token, password: 'Again@New99' })).status, 400, 'single use');
    assert.equal((await ctx.anon.post('/api/auth/login').send({ email: 'staff@brightloop.io', password: 'Brand@New99' })).status, 200);
    assert.equal((await ctx.anon.post('/api/auth/login').send({ email: 'staff@brightloop.io', password: 'Staff@12345' })).status, 401);
  });
});

describe('Role-based access control', () => {
  test('staff cannot manage catalogue, taxes, discounts or users', async () => {
    assert.equal((await staff.post('/api/products', { name: 'X', type: 'service', sales_price: 1 })).status, 403);
    assert.equal((await staff.post('/api/taxes', { name: 'X', rate: 5 })).status, 403);
    assert.equal((await staff.post('/api/discounts', { name: 'X', type: 'fixed', value: 5 })).status, 403);
    assert.equal((await staff.get('/api/users')).status, 403);
  });
  test('admin creates staff users', async () => {
    const r = await admin.post('/api/users', { name: 'New Staff', email: 'ns@brightloop.io', password: 'Staff#9999', role: 'staff' });
    assert.equal(r.status, 201);
  });
  test('customers see only their own subscriptions and invoices', async () => {
    const mine = await customer.get('/api/subscriptions?pageSize=200');
    assert.equal(mine.status, 200);
    assert.ok(mine.body.rows.length > 0);
    const ids = new Set(ctx.q.all('SELECT id FROM subscriptions WHERE customer_id = 1').map((r) => r.id));
    assert.ok(mine.body.rows.every((s) => ids.has(s.id)));
    const other = ctx.q.get('SELECT id FROM subscriptions WHERE customer_id <> 1 LIMIT 1');
    assert.equal((await customer.get(`/api/subscriptions/${other.id}`)).status, 404);
    const otherInv = ctx.q.get('SELECT id FROM invoices WHERE customer_id <> 1 LIMIT 1');
    assert.equal((await customer.get(`/api/invoices/${otherInv.id}`)).status, 404);
    const invs = await customer.get('/api/invoices?pageSize=200');
    assert.ok(invs.body.rows.every((i) => i.customer_name === 'Acme Retail' && i.status !== 'draft'));
  });
  test('customers cannot reach internal endpoints', async () => {
    for (const u of ['/api/customers', '/api/dashboard', '/api/products']) assert.equal((await customer.get(u)).status, 403, u);
    const s = ctx.q.get('SELECT id FROM subscriptions WHERE customer_id = 1 LIMIT 1');
    assert.equal((await customer.post(`/api/subscriptions/${s.id}/invoice_now`)).status, 403);
  });
});

describe('Catalogue, variants & tax engine', () => {
  test('variant attribute adds to base price (Odoo +560)', async () => {
    const odoo = ctx.q.get(`SELECT id FROM attribute_values WHERE value = 'Odoo'`).id;
    const s = await staff.post('/api/subscriptions', { customer_id: 2, plan_id: 1, start_date: TODAY, lines: [{ product_id: 1, quantity: 1, variant_value_ids: [odoo] }] });
    assert.equal(s.status, 201);
    assert.equal(s.body.lines[0].unit_price, 1200 + 560);
    assert.match(s.body.lines[0].description, /Brand: Odoo/);
  });
  test('two values of the same attribute are rejected', async () => {
    const [a, b] = ctx.q.all(`SELECT id FROM attribute_values WHERE value IN ('Odoo','Zoho')`).map((r) => r.id);
    const s = await staff.post('/api/subscriptions', { customer_id: 2, plan_id: 1, start_date: TODAY, lines: [{ product_id: 1, quantity: 1, variant_value_ids: [a, b] }] });
    assert.equal(s.status, 400);
  });
  test('tax rules: default 18%, goods-type rule 12%', async () => {
    const s = await staff.post('/api/subscriptions', { customer_id: 2, plan_id: 1, start_date: TODAY,
      lines: [{ product_id: 3, quantity: 1 }, { product_id: 4, quantity: 1 }] });
    const [support, key] = s.body.lines;
    assert.equal(support.tax_rate, 18);
    assert.equal(key.tax_rate, 12);
  });
  test('product validation returns field errors', async () => {
    const r = await admin.post('/api/products', { name: '', type: 'nope', sales_price: -5 });
    assert.equal(r.status, 400);
    assert.ok(r.body.fields.name && r.body.fields.type && r.body.fields.sales_price);
  });
});

describe('Subscription lifecycle & plan rules', () => {
  test('Draft → Quotation → Confirmed → Active → Closed; illegal jumps blocked', async () => {
    const f = await fixture();
    const s = (await staff.post('/api/subscriptions', { customer_id: f.customer.id, plan_id: f.plan.id, start_date: TODAY, lines: [f.line] })).body;
    assert.equal(s.status, 'draft');
    assert.match(s.number, /^SUB-\d{5}$/);
    assert.equal((await staff.post(`/api/subscriptions/${s.id}/activate`)).status, 409, 'cannot skip to active');
    const q1 = await staff.post(`/api/subscriptions/${s.id}/send_quote`);
    assert.equal(q1.body.status, 'quotation');
    assert.ok(q1.body.quote_valid_until > TODAY);
    assert.ok(ctx.q.get(`SELECT 1 FROM email_outbox WHERE subject LIKE ?`, `Quotation ${s.number}%`), 'quote emailed');
    assert.equal((await staff.post(`/api/subscriptions/${s.id}/confirm`)).body.status, 'confirmed');
    assert.equal((await staff.post(`/api/subscriptions/${s.id}/activate`)).body.status, 'active');
    assert.equal((await staff.post(`/api/subscriptions/${s.id}/close`)).body.status, 'closed');
    assert.equal((await staff.post(`/api/subscriptions/${s.id}/activate`)).status, 409);
  });
  test('expired quotations cannot be confirmed', async () => {
    const f = await fixture();
    const s = (await staff.post('/api/subscriptions', { customer_id: f.customer.id, plan_id: f.plan.id, start_date: TODAY, lines: [f.line] })).body;
    await staff.post(`/api/subscriptions/${s.id}/send_quote`);
    ctx.q.run('UPDATE subscriptions SET quote_valid_until = ? WHERE id = ?', addDays(TODAY, -1), s.id);
    assert.equal((await staff.post(`/api/subscriptions/${s.id}/confirm`)).status, 409);
  });
  test('customer can accept their own quotation', async () => {
    const s = ctx.q.get(`SELECT id FROM subscriptions WHERE customer_id = 1 AND status = 'quotation' AND quote_valid_until >= ?`, TODAY);
    const r = await customer.post(`/api/subscriptions/${s.id}/confirm`);
    assert.equal(r.status, 200);
    assert.equal(r.body.status, 'confirmed');
  });
  test('minimum quantity and availability window are enforced', async () => {
    const f = await fixture({ plan: { min_quantity: 5, available_from: '2026-01-01', available_to: '2026-12-31' } });
    const base = { customer_id: f.customer.id, plan_id: f.plan.id };
    assert.equal((await staff.post('/api/subscriptions', { ...base, start_date: TODAY, lines: [{ ...f.line, quantity: 2 }] })).status, 400);
    assert.equal((await staff.post('/api/subscriptions', { ...base, start_date: '2027-02-01', lines: [{ ...f.line, quantity: 5 }] })).status, 400);
    assert.equal((await staff.post('/api/subscriptions', { ...base, start_date: TODAY, lines: [{ ...f.line, quantity: 5 }] })).status, 201);
  });
  test('early closure blocked when plan disallows it (except admin)', async () => {
    const f = await fixture({ plan: { closable: false, duration_cycles: 12 } });
    const id = await activeSub(f, TODAY);
    assert.equal((await staff.post(`/api/subscriptions/${id}/close`)).status, 409);
    assert.equal((await admin.post(`/api/subscriptions/${id}/close`)).status, 200);
  });
  test('create from quotation template pre-fills plan and lines', async () => {
    const r = await staff.post('/api/subscriptions', { customer_id: 3, template_id: 1, start_date: TODAY });
    assert.equal(r.status, 201, JSON.stringify(r.body));
    assert.equal(r.body.plan_id, 1);
    assert.equal(r.body.lines.length, 2);
    assert.equal(r.body.template_name, 'CRM Starter Bundle');
  });
});

describe('Billing scheduler', () => {
  test('bills each cycle exactly once — re-running never double-bills', async () => {
    const f = await fixture();
    const id = await activeSub(f, '2026-08-15');
    runBilling(TODAY); runBilling(TODAY); runBilling(TODAY);
    const inv = invoicesOf(id);
    assert.deepEqual(inv.map((i) => i.period_start), ['2026-08-15', '2026-09-15', '2026-10-15']);
    assert.deepEqual(inv.map((i) => i.cycle_index), [0, 1, 2]);
    assert.equal(inv[0].period_end, '2026-09-14');
    assert.equal(inv[0].total, 1180); // 1000 + 18% GST
    assert.equal(inv[0].due_date, '2026-08-30');
  });
  test('database rejects a duplicate invoice for the same cycle', async () => {
    const f = await fixture();
    const id = await activeSub(f, '2026-10-01');
    runBilling(TODAY);
    const inv = invoicesOf(id)[0];
    assert.throws(() => ctx.q.run(`INSERT INTO invoices (subscription_id, customer_id, invoice_date, due_date, cycle_index) VALUES (?,?,?,?,0)`, id, inv.customer_id, TODAY, TODAY));
  });
  test('catch-up after downtime: no skipped cycles', async () => {
    const f = await fixture({ plan: { billing_period: 'weekly' } });
    const id = await activeSub(f, '2026-09-01');
    runBilling('2026-09-01');
    assert.equal(invoicesOf(id).length, 1);
    runBilling(TODAY); // scheduler "was down" for two months
    const inv = invoicesOf(id);
    assert.equal(inv.length, 9); // Sep 1 … Oct 27 weekly
    inv.forEach((x, i) => assert.equal(x.cycle_index, i));
  });
  test('month-end anchoring does not drift (Jan 31 → Feb 28 → Mar 31 → Apr 30)', async () => {
    const f = await fixture();
    const id = await activeSub(f, '2026-01-31');
    runBilling('2026-04-30');
    assert.deepEqual(invoicesOf(id).map((i) => i.period_start), ['2026-01-31', '2026-02-28', '2026-03-31', '2026-04-30']);
  });
  test('auto-close on completion after the plan duration', async () => {
    const f = await fixture({ plan: { duration_cycles: 3, auto_close: true } });
    const id = await activeSub(f, '2026-06-01');
    runBilling(TODAY);
    assert.equal(invoicesOf(id).length, 3);
    const s = ctx.q.get('SELECT status, closed_reason, expiry_date FROM subscriptions WHERE id = ?', id);
    assert.equal(s.expiry_date, '2026-09-01');
    assert.equal(s.status, 'closed');
    assert.equal(s.closed_reason, 'completed');
  });
  test('automatic renewal extends the term and keeps billing', async () => {
    const f = await fixture({ plan: { duration_cycles: 2, renewable: true } });
    const id = await activeSub(f, '2026-07-01');
    runBilling(TODAY);
    const s = ctx.q.get('SELECT status, expiry_date FROM subscriptions WHERE id = ?', id);
    assert.equal(s.status, 'active');
    assert.equal(s.expiry_date, '2026-11-01');
    assert.equal(invoicesOf(id).length, 4);
  });
  test('paused subscriptions are not billed; resume skips paused cycles', async () => {
    const f = await fixture({ plan: { pausable: true } });
    const id = await activeSub(f, '2026-07-10');
    runBilling('2026-07-10');
    await staff.post(`/api/subscriptions/${id}/pause`);
    runBilling(TODAY);
    assert.equal(invoicesOf(id).length, 1);
    const r = await staff.post(`/api/subscriptions/${id}/resume`);
    assert.equal(r.body.next_invoice_date, '2026-11-10');
    runBilling(TODAY);
    assert.equal(invoicesOf(id).length, 1);
  });
  test('confirmed subscriptions activate on their start date', async () => {
    const f = await fixture();
    const s = (await staff.post('/api/subscriptions', { customer_id: f.customer.id, plan_id: f.plan.id, start_date: TODAY, lines: [f.line] })).body;
    await staff.post(`/api/subscriptions/${s.id}/send_quote`);
    await staff.post(`/api/subscriptions/${s.id}/confirm`);
    const out = runBilling(TODAY);
    assert.ok(out.activated >= 1);
    assert.equal(invoicesOf(s.id).length, 1);
  });
});

describe('Discount engine', () => {
  test('percentage discount applies as a line when conditions met; tax is on the discounted amount', async () => {
    const d = await admin.post('/api/discounts', { name: 'T10', type: 'percent', value: 10, min_amount: 9000, max_uses: 2 });
    assert.equal(d.status, 201);
    const f = await fixture({ price: 9500 });
    const id = await activeSub(f, '2026-10-20');
    runBilling(TODAY);
    const inv = invoicesOf(id)[0];
    const lines = ctx.q.all('SELECT * FROM invoice_lines WHERE invoice_id = ?', inv.id);
    const dl = lines.find((l) => l.discount_id === d.body.id);
    assert.ok(dl, 'discount line added');
    assert.equal(dl.line_total, -950);
    // Festive ₹500 (min 5000, live) also stacks: subtotal 9500 - 950 - 500 = 8050, +18% = 9499
    assert.equal(inv.discount_total, 1450);
    assert.equal(inv.total, 9499);
    await admin.put(`/api/discounts/${d.body.id}`, { ...d.body, active: false });
  });
  test('usage cap stops the discount; cancelling an invoice releases its usage', async () => {
    const d = (await admin.post('/api/discounts', { name: 'Cap1', type: 'fixed', value: 100, max_uses: 1 })).body;
    const f1 = await fixture(); const f2 = await fixture();
    const a = await activeSub(f1, '2026-10-25'); const b = await activeSub(f2, '2026-10-25');
    runBilling(TODAY);
    const has = (sid) => !!ctx.q.get('SELECT 1 FROM invoice_lines il JOIN invoices i ON i.id = il.invoice_id WHERE i.subscription_id = ? AND il.discount_id = ? AND i.status <> \'cancelled\'', sid, d.id);
    assert.equal(has(a) + has(b), 1, 'only one invoice got the capped discount');
    assert.equal(ctx.q.get('SELECT used_count FROM discounts WHERE id = ?', d.id).used_count, 1);
    const discounted = invoicesOf(has(a) ? a : b)[0];
    await staff.post(`/api/invoices/${discounted.id}/cancel`);
    assert.equal(ctx.q.get('SELECT used_count FROM discounts WHERE id = ?', d.id).used_count, 0);
    const list = (await admin.get('/api/discounts')).body;
    assert.equal(list.find((x) => x.id === d.id).state, 'live');
    await admin.put(`/api/discounts/${d.id}`, { ...d, active: false });
  });
  test('expired discounts are not applied', async () => {
    const d = (await admin.post('/api/discounts', { name: 'Old', type: 'fixed', value: 50, end_date: '2026-10-01' })).body;
    const f = await fixture();
    const id = await activeSub(f, '2026-10-15');
    runBilling(TODAY);
    assert.ok(!ctx.q.get('SELECT 1 FROM invoice_lines WHERE invoice_id = ? AND discount_id = ?', invoicesOf(id)[0].id, d.id));
    assert.equal((await admin.get('/api/discounts')).body.find((x) => x.id === d.id).state, 'expired');
  });
  test('percent over 100 is rejected', async () => {
    assert.equal((await admin.post('/api/discounts', { name: 'Bad', type: 'percent', value: 150 })).status, 400);
  });
});

describe('Invoices & payments', () => {
  let invId;
  before(async () => {
    const f = await fixture({ price: 2000 });
    const id = await activeSub(f, '2026-10-30');
    runBilling(TODAY);
    invId = invoicesOf(id)[0].id;
  });
  test('cannot pay or email a draft invoice', async () => {
    assert.equal((await staff.post('/api/payments', { invoice_id: invId, method: 'card', date: TODAY, amount: 10 })).status, 409);
    assert.equal((await staff.post(`/api/invoices/${invId}/email`)).status, 409);
  });
  test('Draft → Confirmed → partial payment → Paid', async () => {
    const c = await staff.post(`/api/invoices/${invId}/confirm`);
    assert.equal(c.body.status, 'confirmed');
    assert.equal(c.body.total, 2360);
    const e = await staff.post(`/api/invoices/${invId}/email`);
    assert.ok(e.body.emailed_at);
    const p1 = await staff.post('/api/payments', { invoice_id: invId, method: 'bank_transfer', date: TODAY, amount: 1000, notes: 'first' });
    assert.equal(p1.status, 201);
    assert.equal(p1.body.invoice.status, 'confirmed');
    assert.equal(p1.body.invoice.balance, 1360);
    assert.equal((await staff.post('/api/payments', { invoice_id: invId, method: 'card', date: TODAY, amount: 5000 })).status, 400, 'overpayment');
    const p2 = await staff.post('/api/payments', { invoice_id: invId, method: 'card', date: TODAY, amount: 1360 });
    assert.equal(p2.body.invoice.status, 'paid');
    assert.equal(p2.body.invoice.payments.length, 2);
  });
  test('paid invoices cannot be cancelled', async () => {
    assert.equal((await staff.post(`/api/invoices/${invId}/cancel`)).status, 409);
  });
  test('payment validation', async () => {
    const r = await staff.post('/api/payments', { invoice_id: invId, method: 'bitcoin', date: '31/10/2026', amount: -1 });
    assert.equal(r.status, 400);
    assert.ok(r.body.fields.method && r.body.fields.date && r.body.fields.amount);
  });
});

describe('Finance dashboard', () => {
  test('summary figures match the underlying data', async () => {
    const d = (await staff.get('/api/dashboard')).body;
    assert.equal(d.active_subscriptions, ctx.q.get(`SELECT COUNT(*) n FROM subscriptions WHERE status='active'`).n);
    const rev = ctx.q.get('SELECT ROUND(SUM(amount),2) s FROM payments').s;
    assert.equal(Math.round(d.revenue_collected * 100) / 100, rev);
    const od = ctx.q.get(`SELECT COUNT(*) n FROM invoices WHERE status='confirmed' AND due_date < ? AND total > amount_paid`, TODAY).n;
    assert.equal(d.overdue_count, od);
    assert.equal(d.months.length, 12);
  });
  test('filters by date range and customer', async () => {
    const d = (await staff.get('/api/dashboard?from=2026-10-01&to=2026-10-31&customer_id=1')).body;
    const rev = ctx.q.get(`SELECT COALESCE(SUM(p.amount),0) s FROM payments p JOIN invoices i ON i.id=p.invoice_id WHERE i.customer_id=1 AND p.date BETWEEN '2026-10-01' AND '2026-10-31'`).s;
    assert.equal(d.revenue_collected, rev);
    assert.equal((await staff.get('/api/dashboard?customer_id=abc')).status, 400);
  });
  test('overdue filter on invoice list', async () => {
    const r = (await staff.get('/api/invoices?status=overdue&pageSize=200')).body;
    assert.ok(r.rows.every((i) => i.overdue === 1));
  });
});
