// Performance check: loads thousands of records into a temp DB and times every list/report endpoint.
// Run: npm run test:perf   (target: every request < 2000 ms)
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';

const file = path.join(os.tmpdir(), `brightloop-perf-${process.pid}.db`);
process.env.DB_PATH = file;
process.env.NODE_ENV = 'test';
const { default: request } = await import('supertest');
const { createApp } = await import('../src/app.js');
const { seed, DEMO } = await import('../src/seed.js');
const { runBilling } = await import('../src/services/billing.js');

let t = Date.now();
const counts = seed({ bulk: true });
console.log('Bulk data:', counts, `(${((Date.now() - t) / 1000).toFixed(1)}s to generate)`);

const app = createApp();
const { token } = (await request(app).post('/api/auth/login').send(DEMO.admin)).body;
const cust = (await request(app).post('/api/auth/login').send(DEMO.customer)).body.token;
const urls = [
  '/api/dashboard', '/api/dashboard?from=2026-06-01&to=2026-10-31', '/api/dashboard?customer_id=1',
  '/api/subscriptions', '/api/subscriptions?status=active&page=50', '/api/subscriptions?q=Acme',
  '/api/invoices', '/api/invoices?status=overdue', '/api/invoices?page=400', '/api/invoices?q=INV-2026-01',
  '/api/payments', '/api/payments?method=card&from=2026-09-01', '/api/customers?page=60', '/api/customers?q=Kochi',
  '/api/subscriptions/2500', '/api/invoices/20000', '/api/products', '/api/discounts',
];
let worst = 0, fail = false;
for (const u of urls) {
  t = performance.now();
  const r = await request(app).get(u).set('Authorization', `Bearer ${token}`);
  const ms = performance.now() - t;
  worst = Math.max(worst, ms);
  if (r.status !== 200 || ms > 2000) fail = true;
  console.log(`${r.status}  ${ms.toFixed(1).padStart(7)} ms  ${u}`);
}
t = performance.now();
await request(app).get('/api/invoices').set('Authorization', `Bearer ${cust}`);
console.log(`200  ${(performance.now() - t).toFixed(1).padStart(7)} ms  /api/invoices (customer portal)`);
t = performance.now();
const run = runBilling();
console.log(`Idempotent billing re-run over ${counts.subscriptions} subscriptions: ${(performance.now() - t).toFixed(0)} ms, created ${run.invoices_created}`);
console.log(fail ? '\nFAIL: an endpoint exceeded 2s or errored' : `\nPASS: slowest request ${worst.toFixed(1)} ms (< 2000 ms target)`);
for (const f of [file, file + '-wal', file + '-shm']) fs.rmSync(f, { force: true });
process.exit(fail ? 1 : 0);
