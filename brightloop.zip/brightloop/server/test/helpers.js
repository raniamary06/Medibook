process.env.NODE_ENV = 'test';
process.env.DB_PATH = ':memory:';
process.env.DISABLE_SCHEDULER = 'true';

const { default: request } = await import('supertest');
const { createApp } = await import('../src/app.js');
const { openDb, setDb, q } = await import('../src/db.js');
const { seed, DEMO } = await import('../src/seed.js');

export const TODAY = '2026-10-31';

/** Fresh in-memory DB with demo data; returns an agent factory per role. */
export async function setup() {
  process.env.FAKE_TODAY = TODAY;
  setDb(openDb(':memory:'));
  seed({ today: TODAY });
  const app = createApp();
  const login = async (who) => {
    const r = await request(app).post('/api/auth/login').send(DEMO[who]);
    if (r.status !== 200) throw new Error('login failed ' + JSON.stringify(r.body));
    return r.body.token;
  };
  const tokens = { admin: await login('admin'), staff: await login('staff'), customer: await login('customer') };
  const as = (who) => {
    const auth = (req) => req.set('Authorization', `Bearer ${tokens[who]}`);
    return {
      get: (u) => auth(request(app).get(u)),
      post: (u, b) => auth(request(app).post(u)).send(b ?? {}),
      put: (u, b) => auth(request(app).put(u)).send(b ?? {}),
      patch: (u, b) => auth(request(app).patch(u)).send(b ?? {}),
    };
  };
  return { app, as, anon: request(app), q };
}

export { request, q };
